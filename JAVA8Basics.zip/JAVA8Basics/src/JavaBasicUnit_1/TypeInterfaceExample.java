/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_1;

/**
 *
 * @author hp
 */
public class TypeInterfaceExample {
//     public static void main(String[] args) {
//         String s = "Simran Gupta";
//          //StringLengthLambda strlen = (S)->S.length(); 
//         StringLengthLambda strlen = S->S.length(); 
//          System.out.println(strlen.getLength(s));
//    }
//     
//     interface StringLengthLambda
//     {
//         int getLength(String s);
//     }
    
     public static void main(String[] args) {
         
         printLambdaLength(s->s.length());
    }
     
     public static void printLambdaLength(StringLengthLambda l)
     {
           System.out.println(l.getLength("Simran Gupta"));
     }
     
     interface StringLengthLambda
     {
         int getLength(String s);
     }
}


