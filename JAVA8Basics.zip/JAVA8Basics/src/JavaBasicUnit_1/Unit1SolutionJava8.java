/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_1;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import static javafx.scene.input.KeyCode.T;

/**
 *
 * @author hp
 */
public class Unit1SolutionJava8 {
    
    public static void main(String[] args) {
        List<Person> people = Arrays.asList(
        new Person("Simran","Lupta",24),
                new Person("Suhani","Yupta",20),
        new Person("Alpana","Gupta",44),
                new Person("Pankaj","Rupta",52),
                new Person("XYZ","Lupta",52)
                        );
        
        //Step 1 : Sort list by last name
        Collections.sort(people,(p1,p2)-> p1.getLastname().compareTo(p2.getLastname()));
               
        //Step 2 : Create a method that prints all elements in list
         System.out.println("Print all persons : ");
         printConditionally(people,p->true,p->System.out.println(p));
        
        //step 3 : Create a method that prints all people that have last name beginning with L 
                                                            
         System.out.println("Print all persons whose last name starts with L: ");
          printConditionally(people,p-> p.getLastname().startsWith("L"),p->System.out.println(p));
          
            System.out.println("Print all persons whose first name starts with S: ");
        printConditionally(people,p-> p.getFirstname().startsWith("S"),p->System.out.println(p));
        
    }
    private static void printAll(List<Person> people) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        for(Person x : people)
            System.out.println(x);
    }

//    private static void printConditionally(List<Person> people,Condition con) {
//        for(Person x : people)
//         {
//             if(con.test(x))
//             {
//                 System.out.println(x);
//             }
//         }
//        
//    }

//    interface Condition {
//        boolean test(Person p);
//    }
    
//     private static void printConditionally(List<Person> people,Predicate<Person> predicate) {
//        for(Person x : people)
//         {
//             if(predicate.test(x))
//             {
//                 System.out.println(x);
//             }
//         }
//        
//    }
      public  static void printConditionally(List<Person> people,Predicate<Person> predicate, Consumer<Person> consumer) {
        for(Person x : people)
         {
             if(predicate.test(x))
             {
                 consumer.accept(x);
             }
         }
        
    }
    
}
