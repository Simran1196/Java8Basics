/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_1;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import static javafx.scene.input.KeyCode.T;

/**
 *
 * @author hp
 */
public class Unit1SolutionJava7 {
    
    public static void main(String[] args) {
        List<Person> people = Arrays.asList(
        new Person("Simran","Lupta",24),
                new Person("Suhani","Yupta",20),
        new Person("Alpana","Gupta",44),
                new Person("Pankaj","Rupta",52),
                new Person("XYZ","Lupta",52)
                        );
        
        //Step 1 : Sort list by last name
        Collections.sort(people,new Comparator<Person>(){

            @Override
            public int compare(Person o1, Person o2) {
                return o1.getLastname().compareTo(o2.getLastname());
                 }
        });
               
        //Step 2 : Create a method that prints all elements in list
         System.out.println("Print all persons : ");
         printAll(people);
        
        //step 3 : Create a method that prints all people that have last name beginning with L 
//        printLastnameBeginningwithL(people);
          System.out.println("Print all persons whose last name starts with L: ");
          printConditionally(people,new Condition(){

            @Override
            public boolean test(Person p) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                return p.getLastname().startsWith("L");
            }
            
          });
          
            System.out.println("Print all persons whose first name starts with S: ");
        printConditionally(people,new Condition(){

            @Override
            public boolean test(Person p) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                return p.getFirstname().startsWith("S");
            }
            
          });
    }

    private static void printAll(List<Person> people) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        for(Person x : people)
            System.out.println(x);
    }

    private static void printConditionally(List<Person> people,Condition con) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//         for(Person x : people)
//         {
//             if(x.getLastname().startsWith("L"))
//                 System.out.println(x);
//         }
        for(Person x : people)
         {
             if(con.test(x))
             {
                 System.out.println(x);
             }
         }
        
    }

    interface Condition {
        boolean test(Person p);
    }
    
}
