/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_1;

/**
 *
 * @author hp
 */
public class Person {
    private String firstname;
     private String lastname;
      private int age;

    public Person(String firstname, String lastname, int age) {
        super();
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
      
    /**
     *
     * @return
     */
    @Override
     public String toString()
     {
        return "Person [First Name : " + firstname + ", Last Name : " + lastname + ", Age : " + age + "]";
     }
    
}
