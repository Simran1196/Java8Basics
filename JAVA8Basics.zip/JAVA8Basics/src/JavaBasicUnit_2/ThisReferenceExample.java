/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_2;

/**
 *
 * @author hp
 */
public class ThisReferenceExample {
    
    public void doProcess(int i,Process p)
    {
        p.process(i);
    }
    
     public void execute()
    {
        //this here points to ???
       doProcess(10,i->{
            System.out.println("value of i is "+ i);
            System.out.println(this);
       });
    }
     
      public String toString()
            {
                return "This is the main ThisReferenceExample class instance";
            }
     
    public static void main(String[] args) {
        ThisReferenceExample thisReference = new ThisReferenceExample();
//        thisReference.doProcess(10, new Process(){
//            
//            @Override
//            public void process(int a) {
//                
//            }
//            
//            public String toString()
//            {
//                return "This is the anonymous inner class";
//            }
//        });
        
        thisReference.doProcess(10,i->{
            System.out.println("value of i is "+ i);
            //System.out.println(this);
                //This will not work... //non-static variable this cannot be referenced from a static context
        });
        
        thisReference.execute();
    }
}
