/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_2;

/**
 *
 * @author hp
 */
public class ClosureExample {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        doProcess(a,new Process(){

            @Override
            public void process(int a) {
               // b=98;//This is not allowed as it is final in nature. And that's the closure.
               System.out.println(a+b); 
            }
            
        });
    }
    public static void doProcess(int x,Process p)
    {
        p.process(x);
    }
}

interface Process{
    void process(int a);
}
