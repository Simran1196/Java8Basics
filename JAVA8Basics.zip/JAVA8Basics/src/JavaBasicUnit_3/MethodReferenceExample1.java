/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_3;

/**
 *
 * @author hp
 */
public class MethodReferenceExample1 {
    
    public static void main(String[] args) {
        //Thread t  =new Thread(()->printMessage());//taking no arguments and executing a function
        //We have a new new syntax for the above sentence:
        Thread t  =new Thread(MethodReferenceExample1::printMessage);
        t.start();
    }
    
    public static void printMessage()
    {
        System.out.println("Hey!!");
      }
    
}
