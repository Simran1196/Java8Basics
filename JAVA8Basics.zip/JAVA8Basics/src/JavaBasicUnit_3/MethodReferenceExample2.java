/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBasicUnit_3;

import JavaBasicUnit_1.Person;
import static JavaBasicUnit_1.Unit1SolutionJava8.printConditionally;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author hp
 */
public class MethodReferenceExample2 {
    public static void main(String[] args) {
         List<Person> people = Arrays.asList(
        new Person("Simran","Lupta",24),
                new Person("Suhani","Yupta",20),
        new Person("Alpana","Gupta",44),
                new Person("Pankaj","Rupta",52),
                new Person("XYZ","Lupta",52)
                        );
        
         System.out.println("Print all persons : ");
//         printConditionally(people,p->true,p->System.out.println(p));
         printConditionally(people,p->true,System.out::println);// p->method(p)
        
    }
      private  static void printConditionally(List<Person> people,Predicate<Person> predicate, Consumer<Person> consumer) {
        for(Person x : people)
         {
             if(predicate.test(x))
             {
                 consumer.accept(x);
             }
         }
        
    }
}
